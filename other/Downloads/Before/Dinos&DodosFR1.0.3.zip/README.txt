  Thank you for installing Dinos & Dodos FR V 1.0.3!
  Bellow you will find a tutorial on how to install the datapack!

How to Install into a existing world:
Disclaimer: if you have a previous version installed just replace the files with the new ones. While you'll have to replace everything broken in the world yourself the new version will be installed.
Step 1. Find and go into your ".minecraft" folder.
Step 2. Go into the "resourcepacks" folder and drag the "DnDresources" folder into the "resourcepacks" folder.
Step 3. Go back to your ".minecraft" folder go into the "saves" file.
Step 4. In your "saves" folder go to the world you would like to put the datapack into, open the file for that world.
Step 5. Find the "datapacks" folder in that world, if there is not one create a new folder and name it "datapacks".
Step 6. Open the "datapacks" folder and drag the "DnDpack" folder into that folder
Step 7. Go into that world in game and run the command "/reload"
Step 8. Enjoy the datapack, it has now been installed into that world and is ready to be played(make sure you have the resourcepack on when playing!!!)
