  Thank you for installing the Dinos & Dodos: 1996 Edition add-on for Minecraft: 1994!!
  I found it in a filing cabnet, but its the best version to ever reach man kind, so enjoy.
  
  Acrocanthosaurus
  Compsognathus
  Corythosaurus
  
  How to Install:
  1. open your recourse pack folder and put the "Dinosaurs & Dodos" folder into it
  2. Make a new world and make sure that allow cheats is on!
  3. Get into that worlds files and drag the "datapacks" folder into the world
  4. go into the world
  5. put this command into your chat, "/function dinocustom:start"
  6. enjoy!
