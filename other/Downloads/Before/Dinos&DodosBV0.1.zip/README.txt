  Thank you for installing the Dinos & Dodos Data Pack made by Ragnorak!
  Please do remember this is the first version of the datapack and only has 3 dinosaurs so far named bellow will 
  be all the ones added so far, please keep in mind you can only make things for these dinosaurs! But you can still
  get bones for other dinosaurs, you just cant use the bones!
  
  Acrocanthosaurus
  Compsognathus
  Corythosaurus
  
  How to Install:
  1. open your recourse pack folder and put the "Dinosaurs & Dodos" folder into it
  2. Make a new world and make sure that allow cheats is on!
  3. Get into that worlds files and drag the "datapacks" folder into the world
  4. go into the world
  5. put this command into your chat, "/function dinocustom:start"
  6. enjoy!

  Recipes:
  Knowing that most people wouldnt know the crafting recipes in the Data Pack there should be a folder somewhere in
  here that holds all screenshots of all the crafting recipes!
  In order to craft any of the new crafting stations you will need to place a dispencer facing up, and then place a
  armor stand on top of it, this is becaues fully optimisable custom crafting recipes in crafting tables are not available yet!